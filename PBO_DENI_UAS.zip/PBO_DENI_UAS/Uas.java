// proses import liblary
import java.sql.*;
import java.util.Scanner;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

//membuat clas main utama untuk koneksi ke db
public class Uas {
    // dipergunakan untuk melakukan koneksi mysql dengan vscode serta program
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/uas_deni";
    static final String USER = "root";
    static final String PASS = "";

    // membuat main untuk program run
    public static void main(String[] args) {
        // Kode ini digunakan untuk menghubungkan data ke sebuah database menggunakan
        // JDBC di Java
        // Kode Connection untuk koneksi dan Statement dipergunakan sebagai eksekutor
        Connection koneksi = null;
        Statement eksekusi = null;
        try {
            Class.forName(JDBC_DRIVER);
            koneksi = DriverManager.getConnection(DB_URL, USER, PASS);
            eksekusi = koneksi.createStatement();
            // membuat menu
            Scanner input = new Scanner(System.in);
            int pilihan;
            do {
                System.out.println("-----------------------------------------");
                System.out.println("Aplikasi CRUD sederhana data product:");
                System.out.println("-----------------------------------------");
                System.out.println("1. Import Json");
                System.out.println("2. Tampilkan data category");
                System.out.println("3. Tampilkan data Product");
                System.out.println("4. Input data Product");
                System.out.println("5. Edit data Product");
                System.out.println("6. Hapus data");
                System.out.println("7. Keluar");
                System.out.print("Masukkan pilihan: ");
                pilihan = input.nextInt();
                System.out.println("-----------------------------------------");

                switch (pilihan) {
                    case 1:
                        ImportJSON_file();
                        break;
                    case 2:
                        showAllcategory(eksekusi);
                        break;
                    case 3:
                        showAll(eksekusi);
                        break;
                    case 4:
                        create(eksekusi, input);
                        break;
                    case 5:
                        edit(eksekusi, input);
                        break;
                    case 6:
                        delete(eksekusi, input);
                        break;
                    case 7:
                        System.out.println("Terima kasih telah menggunakan aplikasi ini.");
                        break;
                    default:
                        System.out.println("Pilihan tidak valid. Silakan coba lagi.");
                        break;
                }
            } while (pilihan != 6);

            eksekusi.close();
            koneksi.close();
        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (eksekusi != null)
                    eksekusi.close();
            } catch (SQLException se2) {
            }
            try {
                if (koneksi != null)
                    koneksi.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }

        }

    }

    private static void ImportJSON_file(){
            // Koneksi ke database    
            Connection conn = Database.getConnection();
            try {
                // Membaca file JSON

                FileReader reader = new FileReader("categories.json");
                JSONParser jsonParser = new JSONParser();
                JSONArray jsonArray = (JSONArray) jsonParser.parse(reader);
    
                // Menyiapkan statement untuk menyimpan data ke tabel "Category"
                String sql = "INSERT INTO Category (id, name) VALUES (?, ?)";
                PreparedStatement statement = conn.prepareStatement(sql);
    
                // Iterasi setiap objek dalam array
                for (Object obj : jsonArray) {
                    JSONObject jsonObject = (JSONObject) obj;
    
                    // Mengambil data dari file JSON
                    int id = Integer.parseInt(jsonObject.get("id").toString());
                    String name = jsonObject.get("name").toString();
    
                    // Menyimpan data ke tabel "Category"
                    statement.setInt(1, id);
                    statement.setString(2, name);
                    statement.executeUpdate();
                }
    
                System.out.println("Data berhasil diimpor ke tabel 'Category'");
    
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    private static void showAllcategory(Statement eksekusi) throws SQLException {
        String sql = "SELECT * FROM category";
        ResultSet rs = eksekusi.executeQuery(sql);
        System.out.println("-----------------------------------------");
        System.out.println("Menampilkan Data category :");
        System.out.println("-----------------------------------------");
        while (rs.next()) {
            // ngambil data di database kumudian di tampilkan
            int id = rs.getInt("id");
            String name = rs.getString("name");
            System.out.println("Id : " + id + "| Name : " + name);
        }
        System.out.println();
    }

    private static void showAll(Statement eksekusi) throws SQLException {
        String sql = "SELECT * FROM product";
        ResultSet rs = eksekusi.executeQuery(sql);
        System.out.println("-----------------------------------------");
        System.out.println("Menampilkan Data Product:");
        System.out.println("-----------------------------------------");
        while (rs.next()) {
            // ngambil data di database kumudian di tampilkan
            int id = rs.getInt("id");
            int category_id = rs.getInt("category_id");
            String name = rs.getString("name");
            String des = rs.getString("description");
            Double price = rs.getDouble("price");
            String status = rs.getString("status");
            System.out.println("Id : " + id + " | Category : " + category_id + " | Name : " + name + " | Description : "
                    + des + " | Price : " + price + " | Status : " + status);
        }
        System.out.println();
    }

    private static void create(Statement eksekusi, Scanner input) throws SQLException {
        int category;
        System.out.println("\n=========================");
        System.out.println("Category Barang : ");
        System.out.println("1. Eletronik ");
        System.out.println("2. Perlengkapan Olah Raga ");
        System.out.println("3. Fashion");
        System.out.println("=========================");

        System.out.print("Masukkan Category barang dengan angka: ");
        category = input.nextInt();

        if (category == 1 || category == 2 || category == 3) {
            System.out.print("Masukkan id barang: ");
            int id = input.nextInt();
            input.nextLine();

            System.out.print("Masukkan Nama Barang: ");
            String name = input.nextLine();

            System.out.print("Masukkan Descripsi barang: ");
            String des = input.nextLine();

            System.out.print("Masukkan Harga barang: ");
            Float price = input.nextFloat();

            System.out.print("Masukkan Status barang: ");
            String status = input.next();

            String sql = "INSERT INTO product (id, category_id, name, description, price, status) VALUES ('" + id
                    + "','" + category + "','" + name + "','" + des + "','" + price + "','" + status + "')";
            eksekusi.executeUpdate(sql);
            System.out.println("-----------------------------------------");
            System.out.println("Data Mahasiswa berhasil ditambahkan.");
            System.out.println("-----------------------------------------\n");
        } else {
            System.out.println("== PILIHAN TIDAK VALID ==");
        }
    }

    private static void edit(Statement eksekusi, Scanner input) throws SQLException {
        System.out.print("Masukkan id barang yang akan diubah: ");
        int id = input.nextInt();
        input.nextLine();

        System.out.print("Masukkan nama barang baru: ");
        String name = input.next();
        input.nextLine();

        int category;
        System.out.println("\n=========================");
        System.out.println("Category Barang : ");
        System.out.println("1. Eletronik ");
        System.out.println("2. Perlengkapan Olah Raga ");
        System.out.println("3. Fashion");
        System.out.println("=========================");

        System.out.print("Masukkan Category barang yang baru dengan angka: ");
        category = input.nextInt();

        if (category == 1 || category == 2 || category == 3) {

            System.out.print("Masukkan Descripsi barang baru: ");
            String des = input.nextLine();

            System.out.print("Masukkan Harga barang baru: ");
            Float price = input.nextFloat();

            System.out.print("Masukkan Status barang baru: ");
            String status = input.next();

            String sql = "UPDATE product SET category_id = '" + category + "', description = '" + des + "', price = '"
                    + price + "', status = '" + status + "', name = '" + name + "'  WHERE id = " + id;
            eksekusi.executeUpdate(sql);
            System.out.println("-----------------------------------------");
            System.out.println("Data product berhasil diubah.");
            System.out.println("-----------------------------------------\n");
        } else {
            System.out.println("== PILIHAN TIDAK VALID ==");
        }
    }

    private static void delete(Statement eksekusi, Scanner input) throws SQLException {
        System.out.print("Masukkan id product yang akan dihapus: ");
        int id = input.nextInt();

        String sql = "DELETE FROM product WHERE id = " + id;
        eksekusi.executeUpdate(sql);
        System.out.println("-----------------------------------------");
        System.out.println("Data product berhasil dihapus.");
        System.out.println("-----------------------------------------\n");
    }
}